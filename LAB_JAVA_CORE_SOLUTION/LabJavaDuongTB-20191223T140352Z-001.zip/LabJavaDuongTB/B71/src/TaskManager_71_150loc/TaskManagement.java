package TaskManager_71_150loc;

import java.util.ArrayList;
import java.util.Date;

public class TaskManagement {
    ArrayList<Task> list = new ArrayList<>();
    Validation v = new Validation();
   
        public void inputTask() {
        int id;
        if (list.isEmpty()) {
            id = 1;
        } else {
            id = list.get(list.size() - 1).getId() + 1;
        }
        String name ="";
        do{
            name= v.getText("Enter name: ");
        }while(!name.matches("[a-zA-Z ]+"));
        
        int typeid = v.getChoice("Input type id: ");
        String date = v.getDate();
        double from = v.getFrom();
        double to = v.getTo(from);
        String assign = v.getText("Input assignee: ");
        String reviewer = v.getText("Input reviewer: ");
        Task e = new Task(id, name, typeid, date, from, to, assign, reviewer);
        addTask(e);
    }
        
        public void addTask(Task e){
            list.add(e);
            System.out.println("Add successfully!!!");
        }
        
        public void inputDelete(){
          System.out.print("Enter ID:");
          int findId = findTaskExist(list,v.checkInputInt());
          deleteTask(findId);
        }
    
    public void deleteTask(int findId) {
        if (list.isEmpty()) {
            System.out.println("List empty");
            return;
        }
        if (findId != -1) {
            list.remove(findId);
            for (int i = findId; i < list.size(); i++) {
                list.get(i).setId(list.get(i).getId() - 1);
            }
            System.out.println("Delete success!!!.");
        }
    }
    
    public int findTaskExist(ArrayList<Task>list,int id) {
        
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId() == id) {
                return i;
            }
        }
        System.out.println("Not found.");
        return -1;
    }

    public void display() {
        if (list.isEmpty()) {
            System.out.println("List empty.");
            return;
        }
        System.out.println("------------display all----------------");
        System.out.printf("%-5s%-15s%-15s%-15s%-15s%-15s%-15s\n",
                "ID", "Name", "Task Type", "Date", "Time", "Assign", "Reviewer");
//        for (int i = 0; i < list.size(); i++){
//            System.out.println(i);
//        }
        for(Task t: list){
            System.out.println(t.toString());
        }
    }

}
