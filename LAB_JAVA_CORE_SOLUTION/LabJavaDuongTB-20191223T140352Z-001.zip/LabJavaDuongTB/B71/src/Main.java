/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TaskManager_71_150loc;

public class Main {

    TaskManagement t = new TaskManagement();
    Validation v = new Validation();

    public void menu() {
        while (true) {
            System.out.println("1. Add task");
            System.out.println("2. Delete task");
            System.out.println("3. Show task");
            System.out.println("4. Exit");
            int choice = v.getChoice("Enter your choice: ");
            switch (choice) {
                case 1:
                    t.inputTask();
                    break;
                case 2:
                    t.inputDelete();
                    break;
                case 3:
                    t.display();
                    break;
                case 4:
                    System.exit(0);
            }
        }

    }

    public static void main(String[] args) {
     Main m = new Main();
     m.menu();
    }
}
