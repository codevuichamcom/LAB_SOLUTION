
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class ManageEastAsiaCountries {
    Validation v = new Validation();
    Scanner sc = new Scanner(System.in);
    
    
    //allow user input infomation of contries
    public void inputCountry(ArrayList<Country> list) {
        System.out.print("Enter code of contry: ");
        String countryCode = v.checkInputString();
        //check code contry exist or not
        if (!checkCountryExist(list, countryCode)) {
            System.out.println("Country exist.");
            return;
        }
        System.out.print("Enter name of contry: ");
        String countryName = v.checkInputString();
        System.out.print("Enter total area: ");
        double countryArea = v.checkInputDouble();
        System.out.print("Enter terrain of contry: ");
        String countryTerrain = v.checkInputString();
        Country e = new Country(countryTerrain, countryCode, countryName, countryArea);
        addCountry(list, e);
    }
    
    public void addCountry(ArrayList<Country> list,Country e){
        list.add(e);
        System.out.println("Add successfully!!");
    }

    //display infomation of country
    public void printCountry(ArrayList<Country> list) {
        System.out.printf("%-10s%-25s%-20s%-25s\n", "ID", "Name", "Total Area",
                "Terrain");
        for (Country country : list) {
            country.display();
        }
    }

    //display infomation sort name in ascending
    public void printCountrySorted(ArrayList<Country> list) {
        Collections.sort(list,new Comparator<Country>() {
            @Override
            public int compare(Country o1, Country o2) {
                return o1.getCountryName().compareTo(o2.getCountryName());
            }
        });
        System.out.printf("%-10s%-25s%-20s%-25s\n", "ID", "Name", "Total Area",
                "Terrain");
        for (Country country : list) {
            country.display();
        }
    }
    
    public void inputSearchByName(ArrayList<Country> list){
       System.out.print("Enter the name you want to search for: ");
        String countryName = v.checkInputString();
        searchByName(list, countryName);
        
    }

    //allow user search infomation contry by name
    public void searchByName(ArrayList<Country>list,String countryName) {
        
        System.out.printf("%-10s%-25s%-20s%-25s\n", "ID", "Name", "Total Area",
                "Terrain");
        for (Country country : list) {
            if (country.getCountryName().equalsIgnoreCase(countryName)) {
                country.display();
            }
        }
    }

    //check country exist by code
    public boolean checkCountryExist(ArrayList<Country> list, String countryCode) {
        for (Country country : list) {
            if (country.getCountryCode().equalsIgnoreCase(countryCode)) {
                return false;
            }
        }
        return true;
    }
    
}