
import java.util.ArrayList;

public class Main {
    Validation v = new Validation();
    public void menu(){
        System.out.println("1. Input the information of 11 countries in East Asia");
        System.out.println("2. Display the information of country you've just input");
        System.out.println("3. Search the information of country by user-entered name");
        System.out.println("4. Display the information of countries sorted name in ascending");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
        }

    public static void main(String[] args) {
        Validation v = new Validation();
        ManageEastAsiaCountries m = new ManageEastAsiaCountries();
        Main m1 = new Main();
        ArrayList<Country> list = new ArrayList<>();
        //loop until user want to exist
        while (true) {
            m1.menu();
            int choice = v.checkInputIntLimit(1, 5);
            switch (choice) {
                case 1:
                    m.inputCountry(list);
                    break;
                case 2:
                    m.printCountry(list);
                    break;
                case 3:
                    m.inputSearchByName(list);
                    break;
                case 4:
                    m.printCountrySorted(list);
                    break;
                case 5:
                    return;
            }
        }
    }
}