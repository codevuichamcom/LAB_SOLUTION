
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;


public class Main {
    Validation v = new Validation();
    
        public void inputStudent(ArrayList<Student> list) {
        System.out.println("Please input student information ");
        System.out.print("Name: ");
        String name = v.checkInputString();
        System.out.print("Classes: ");
        String classes = v.checkInputString();
        System.out.print("Mark: ");
        float mark = v.checkInputFloat();
        Student e = (new Student(name, mark, classes));
        addStudent(list,e);
    }
        
        public void addStudent(ArrayList<Student> list,Student e){
            list.add(e);
            System.out.println("Add successfully!!!");
        }

    public void print(ArrayList<Student> list) {
        if (list.isEmpty()) {
            System.err.println("List empty.");
            return;
        }
        Collections.sort(list,new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });          
        for (int i = 0; i < list.size(); i++) {
            System.out.println("--------Student " + i + 1 + "--------");
            System.out.println("Name: " + list.get(i).getName());
            System.out.println("Classes: " + list.get(i).getClasses());
            System.out.println("Mark: " + list.get(i).getMark());
        }
    }

    public void display() {
        ArrayList<Student> list = new ArrayList<>();
        inputStudent(list);
        while (true) {
            System.out.print("Do you want to enter more student information?(Y/N): ");
            if (v.checkInputYN()) {
                inputStudent(list);
            } else {
                break;
            }
        }
        print(list);
    }

    public static void main(String[] args) {
        Main m = new Main();
        m.display();
    }
}