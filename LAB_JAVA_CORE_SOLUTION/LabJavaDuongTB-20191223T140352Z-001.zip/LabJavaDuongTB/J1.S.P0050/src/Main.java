
public class Main {
   
    
     //dispaly menu
    public void menu() {
        System.out.println("\n1. Calculate Superlative Equation");
        System.out.println("2. Calculate Quadratic Equation");
        System.out.println("3. Exit");
        System.out.print("Enter your choice: ");
        }

    public static void main(String[] args) {
            Validation v = new Validation();
            Main m = new Main();
            Manager m1 = new Manager();
        //loop until user want to exit
        
        while (true) {
            m.menu();
            int choice = v.checkInputIntLimit(1, 3);
            switch (choice) {
                case 1:
                    m1.superlativeEquation();
                    break;
                case 2:
                    m1.quadraticEquation();
                    break;
                case 3:
                    return;
            }
        }
    }
}