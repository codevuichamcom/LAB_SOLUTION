

import java.util.Scanner;

/**
 *
 * @author THAYCACAC
 */
public class Manager {
    Validation v = new Validation();
    Scanner in = new Scanner(System.in);


    //allow user calculate Superlative Equation
    public void superlativeEquation() {
        System.out.print("Enter A: ");
        double a = v.checkInputDouble();
        System.out.print("Enter B: ");
        double b = v.checkInputDouble();
        double x = -b / a;
        System.out.println("Solution: x=" + x);
        System.out.print("Number is odd: ");
        if (v.isOdd(a)) {
            System.out.print(a + " ");
        }
        if (v.isOdd(b)) {
            System.out.print(b + " ");
        }
        if (v.isOdd(x)) {
            System.out.print(x + " ");
        }
        System.out.print("\nNumber is even: ");
        if (!v.isOdd(a)) {
            System.out.print(a + " ");
        }
        if (!v.isOdd(b)) {
            System.out.print(b + " ");
        }
        if (!v.isOdd(x)) {
            System.out.print(x + " ");
        }
        System.out.print("\nNumber is perfect square: ");
        if (v.checkSquareNumber(a)) {
            System.out.print(a + " ");
        }
        if (v.checkSquareNumber(b)) {
            System.out.print(b + " ");
        }
        if (v.checkSquareNumber(x)) {
            System.out.print(x + " ");
        }
    }

    //allow user calculate Quadratic Equation
    public void quadraticEquation() {
        System.out.print("Enter A: ");
        double a = v.checkInputDouble();
        System.out.print("Enter B: ");
        double b = v.checkInputDouble();
        System.out.print("Enter C: ");
        double c = v.checkInputDouble();
        double delta = b * b - 4 * a * c;
        double x1 = (-b + Math.sqrt(delta)) / (2 * a);
        double x2 = (-b - Math.sqrt(delta)) / (2 * a);
        System.out.println("Solution: x1 = " + x1 + " and x2 = " + x2);
        System.out.print("Number is odd: ");
        if (v.isOdd(a)) {
            System.out.print(a + " ");
        }
        if (v.isOdd(b)) {
            System.out.print(b + " ");
        }
        if (v.isOdd(c)) {
            System.out.print(c + " ");
        }
        if (v.isOdd(x1)) {
            System.out.print(x1 + " ");
        }
        if (v.isOdd(x2)) {
            System.out.print(x2 + " ");
        }
        System.out.println();
        System.out.print("\nNumber is even: ");
        if (!v.isOdd(a)) {
            System.out.print(a + " ");
        }
        if (!v.isOdd(b)) {
            System.out.print(b + " ");
        }
        if (!v.isOdd(c)) {
            System.out.print(b + " ");
        }
        if (!v.isOdd(x1)) {
            System.out.print(x1 + " ");
        }
        if (!v.isOdd(x2)) {
            System.out.print(x1 + " ");
        }
        System.out.println();
        System.out.print("\nNumber is perfect square: ");
        if (v.checkSquareNumber(a)) {
            System.out.print(a + " ");
        }
        if (v.checkSquareNumber(b)) {
            System.out.print(b + " ");
        }
        if (v.checkSquareNumber(c)) {
            System.out.print(c + " ");
        }
        if (v.checkSquareNumber(x1)) {
            System.out.print(x1 + " ");
        }
        if (v.checkSquareNumber(x2)) {
            System.out.print(x2 + " ");
        }
        System.out.println();
    }
}