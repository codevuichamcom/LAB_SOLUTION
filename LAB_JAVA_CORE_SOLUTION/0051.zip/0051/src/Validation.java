
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Win 8 32bit VS7
 */
public class Validation {
    Scanner sc = new Scanner(System.in);
    
    //    //check user input number limit
    public int checkInputInt(int min, int max) {
        //loop until user input correct
        while (true) {
            try {
                int number = Integer.parseInt(sc.nextLine());
                if (number < min || number > max) {
                    System.out.println("please input between " + min + ", " + max + ":");

                }
                return number;
            } catch (Exception e) {
                System.out.println("Please input interger number");
                
            }
        }
    }

    //allow user input number double
    public double checkInputDouble() {
        //loop until user input correct
        while (true) {
            try {
                double number = Double.parseDouble(sc.nextLine());
                
                return number;
            } catch (Exception e) {
                System.out.println("Please input double number");
               
            }
        }
    }

    //allow user input operator
    public String checkInputOperator() {
        //loop until user input correct
        while (true) {
            String number = sc.nextLine().trim();
            if (number.isEmpty()) {
                System.out.println("Not empty");
            } else if (number.equals("+") || number.equals("-")
                    || number.equals("*") || number.equals("/")
                    || number.equals("^") || number.equals("=")) {
                return number;
            } else {
                System.out.println("Please input (+, -, *, /, ^)");
            }
            
        }
    }

    //allow user input number
     public double inputNumber() {
        System.out.print("Enter number: ");
        double number = checkInputDouble();
        return number;
    }

   
    
}
