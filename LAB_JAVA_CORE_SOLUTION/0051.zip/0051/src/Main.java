public class Main {
     public void menu() {
        System.out.println("1. Normal Calculator");
        System.out.println("2. BMI Calculator");
        System.out.println("3. Exit");
        System.out.print("Enter your choice: ");
        
    }

    public static void main(String[] args) {
        //loop until user want to exit
        Validation v = new Validation();
        Main m1 = new Main();
        Manager m = new Manager();
        while (true) {
            m1.menu();
            int choice = v.checkInputInt(1,3);
            
            switch (choice) {
                case 1:
                    m.normalCalculator();
                    break;
                case 2:
                    m.BMICalculator();
                    break;
                case 3:
                    return;
            }
        }

    }
}