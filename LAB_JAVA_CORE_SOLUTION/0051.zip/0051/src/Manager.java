import java.util.Scanner;

/**
 *
 * @author THAYCACAC
 */
public class Manager {
    Validation v = new Validation();
    Scanner in = new Scanner(System.in);

         //allow user calculator normal
    public void normalCalculator() {
        double number;
        System.out.print("Enter number: ");
        number = v.checkInputDouble();
        while (true) {
            System.out.print("Enter operator: ");
            String operator = v.checkInputOperator();
            if (operator.equals("+")) {
                number += v.inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equals("-")) {
                number -= v.inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equals("*")) {
                number *= v.inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equals("/")) {
                number /= v.inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equals("^")) {
                number = Math.pow(number, v.inputNumber());
                System.out.println("Memory: " + number);
            }
            if (operator.equals("=")) {
                System.out.println("Result: " + number);
                return;
            }
        }

    }

        public void BMICalculator() {
        System.out.println("Enter Weight(kg): ");
        double weight = v.checkInputDouble();
        System.out.println("Enter Height(cm): ");
         double height = v.checkInputDouble();
//        double number = weight/((height/100.0)*(height/100.0));
//        System.out.println(String.format("BMI number: %.2f", number));
        double bmi = weight/((height/100.0)*(height/100.0));
        System.out.println(String.format("BMI number: %.2f", bmi));
        if (bmi < 19) {
            System.out.print("BMI Status:");
            System.out.println("Under-standard");
        }
        if (bmi >= 19 && bmi < 25) {
            System.out.print("BMI Status:");
            System.out.println("Standard");
        }
        if (bmi >= 25 && bmi < 30) {
            System.out.print("BMI Status:");
            System.out.println("Overweight");
        }
        if (bmi >= 30 && bmi < 40) {
            System.out.print("BMI Status:");
            System.out.println("Fat - should lose weight");
        }
        if (bmi >= 40) {
            System.out.print("BMI Status:");
            System.out.println("Very fat - should lose weight immediately");
        }
    }
}