
import java.util.Scanner;

public class Bills {
    Validation v = new Validation();
    Scanner sc= new Scanner(System.in);
      //Get array bills that user input
    public int[] inputBills() {
        System.out.print("Input number of bill: ");
        int size = v.checkInputInt();
        int[] bills = new int[size];
        //allow user input bills
        for (int i = 0; i < bills.length; i++) {
            System.out.print("Input value of bill " + (i + 1) + ": ");
            bills[i] = v.checkInputInt();
        }
        return bills;
    }

    //Get amount that user input
    public Wallet inputWallet() {
        System.out.print("Input value of wallet: ");
        Wallet wallet = new Wallet();
               wallet.setMoney(v.checkInputInt()) ;
        return wallet;
    }

    //Calculate the total amount of the bills
    public int calcTotal(int[] bills) {
        int total = 0;
        for (int i = 0; i < bills.length; i++) {
            total += bills[i];
        }
        return total;
    }

    //Check whether the amount in the wallet is enough to pay. 
    public boolean payMoney(int total, int wallet) {
        if (total > wallet) {
            return false;
        } else {
            return true;
        }
    }

    //Print total of bill and result
    public void printTotalAndResult(int[] bills, int wallet) {
        int total = calcTotal(bills);
        System.out.println("This is total of bill: " + total);
        if (payMoney(total, wallet)) {
            System.err.println("You can buy it");
        } else {
            System.err.println("You can't buy it.");
        }
    }
    
}
