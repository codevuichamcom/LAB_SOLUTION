
import java.util.Scanner;


public class Validation {
     Scanner in = new Scanner(System.in);

    //Check user in put a number type int
    public int checkInputInt() {
        while (true) {
            try {
                int result = Integer.parseInt(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Please input a number.");
                System.out.print("Enter again: ");
            }
        }
    }
}
