
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Win 8 32bit VS7
 */
public class Main {


  

    public static void main(String[] args) {
        Bills b= new Bills();
        //allow user input input bill
        int[] bills = b.inputBills();
        //allow user in put amount of wallet
        
        Person p = new Person();
        Wallet wallet = b.inputWallet();
        p.setWallet(wallet);
        //print total of bill and result
        b.printTotalAndResult(bills, p.getWallet().getMoney());
    }
    
}
